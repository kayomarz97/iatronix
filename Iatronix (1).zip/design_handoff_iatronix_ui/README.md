# Handoff: Iatronix UI Redesign

## Overview
A high-fidelity redesign of the Iatronix frontend — a BYOK evidence-based medical reference tool. This covers the full search flow: Home → Loading (pipeline animation) → Results (with sections, flowcharts, tables, evidence grading).

## About the Design Files
The files in this bundle (`Iatronix Prototype.html`) are **design references created in HTML/React** — interactive prototypes showing intended look and behaviour. They are **not** production code to copy verbatim.

Your task is to **recreate these designs inside the existing Next.js 14 (App Router) + TypeScript + Tailwind CSS codebase**, using its established patterns, component conventions, and libraries. The prototype uses inline React + Babel for portability; in production these should become proper Next.js components with Tailwind classes and the existing `globals.css` design tokens.

## Fidelity
**High-fidelity.** Pixel-precise mockups with final colours, typography, spacing, and interactions. Recreate UI pixel-faithfully using the codebase's existing libraries, but adapt patterns (e.g. replace inline styles with Tailwind classes, use Next.js `<Link>` instead of `<a>`, etc.).

---

## Design Tokens

### Typography
| Token | Value |
|---|---|
| Font (UI) | `DM Sans` — weights 400, 500, 600, 700 |
| Font (data/mono) | `DM Mono` — weights 400, 500 |
| Body size | 16px base |
| Font smoothing | antialiased |

Add to `globals.css`:
```css
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap');

body {
  font-family: 'DM Sans', system-ui, sans-serif;
}
```

### Colour Tokens (Dark — default)
| CSS Var | Hex | Usage |
|---|---|---|
| `--bg-base` | `#07101e` | Page background |
| `--bg-surface` | `#0f1c2e` | Card/panel background |
| `--bg-elevated` | `#162236` | Elevated surface, table header |
| `--bg-hover` | `#1e2f44` | Hover state |
| `--border` | `#1e3048` | Dividers, card borders |
| `--border-focus` | `#3b82f6` | Input focus ring |
| `--text-primary` | `#f0f6ff` | Main text |
| `--text-secondary` | `#8ba3be` | Body copy, labels |
| `--text-muted` | `#4d6a84` | Placeholders, captions |
| `--accent` | `#3b82f6` | Primary CTA, links |
| `--accent-hover` | `#2563eb` | CTA hover |
| `--success` | `#10b981` | LOE I, safe states |
| `--warning` | `#f59e0b` | LOE II, caution states |
| `--danger` | `#ef4444` | LOE III, contra states |

### Colour Tokens (Light override)
| CSS Var | Hex |
|---|---|
| `--bg-base` | `#f4f7fb` |
| `--bg-surface` | `#ffffff` |
| `--bg-elevated` | `#eef2f7` |
| `--border` | `#dce3ed` |
| `--text-primary` | `#0d1b2a` |
| `--text-secondary` | `#4a637a` |
| `--accent` | `#2563eb` |

Apply via `[data-theme="light"]` on `<html>`.

### Border Radius
```
--radius-sm: 6px
--radius-md: 10px
--radius-lg: 16px
--radius-xl: 24px
```

### Shadows
```
--shadow-sm: 0 1px 4px rgba(0,0,0,0.5)
--shadow-md: 0 4px 24px rgba(0,0,0,0.6)
--shadow-lg: 0 8px 48px rgba(0,0,0,0.7)
```
*(halve the opacity values for light mode)*

### Evidence Badge Colours
```
LOE I  → #10b981 (emerald)
LOE II → #3b82f6 (blue)
LOE III → #64748b (slate)

COR I   → #10b981
COR IIa → #06b6d4 (cyan)
COR IIb → #f59e0b (amber)
COR III → #ef4444 (red)
```
Badge style: `font-mono, font-size 10–11px, padding 2px 7px, border-radius 4px, background color@18% opacity, border color@35% opacity`.

---

## Screens

### 1. Home Screen (`/`)
**File:** `src/app/page.tsx`

**Layout:**
- Full-viewport flex column, centred vertically and horizontally
- Max-width content column: `560px` (hero) / `620px` (search + categories)
- Padding: `3rem 1.5rem`

**Hero block:**
- Logo icon: 72×72px rounded-20 container, `rgba(34,211,238,0.06)` bg, `rgba(34,211,238,0.15)` border — contains the favicon SVG at 52px (see Assets)
- Heading: `clamp(2.4rem, 6vw, 3.4rem)`, weight 800, `letter-spacing: -0.04em`, gradient fill `linear-gradient(135deg, var(--text-primary) 50%, #22D3EE)`
- Subheading: `1.05rem`, `var(--text-secondary)`, weight 400

**Search bar:**
- Border radius: `var(--radius-xl)` (24px)
- Input padding: `15px 110px 15px 48px`
- Search icon (left, 18px): colour shifts from `--text-muted` to `--accent` on focus
- Submit button (right, inside input): `8px 20px` padding, `--accent` bg when query present, disabled state `--bg-elevated`
- Focus ring: `0 0 0 3px var(--accent-glow)` + `--shadow-md`
- Border: `1px solid --border`, shifts to `--border-focus` on focus

**Sign-in nudge:**
- `rgba(59,130,246,0.06)` bg, `rgba(59,130,246,0.14)` border, `--radius-md`, `0.78rem`

**Category cards (6-up grid):**
- Grid: `repeat(auto-fill, minmax(158px, 1fr))`, gap `0.6rem`, max-width `620px`
- Card: `0.875rem 1rem` padding, `--bg-surface` bg → `--bg-elevated` on hover
- Border: `--border` → `--border-focus` on hover
- Transform: `translateY(-2px)` on hover, `--shadow-md`
- Icon: emoji `1.3rem`; label: `0.8rem`, weight 500

**Entry animation:** `fadeUp` (opacity 0→1 + translateY 14px→0, 380ms cubic-bezier(0.22,1,0.36,1)), staggered delays on hero (0ms), search (60ms), nudge/categories (100–130ms).

---

### 2. Loading Screen (pipeline animation)
**Triggered:** After submitting any query; replaces page content.

**Layout:** Full-viewport centred column, `max-width: 460px`

**Elements:**
- Query label: `0.68rem` mono uppercase `--text-muted`, then `1rem` weight-600 query text
- Progress bar: `3px` height, `--border` track, `linear-gradient(90deg, --accent, #10b981)` fill — width animated via JS elapsed-time percentage
- 7 pipeline stage rows (see stage list below)

**Stage row states:**
| State | Circle | Text colour |
|---|---|---|
| Pending | 20px circle, `--border` bg | `--text-muted`, opacity 0.3 |
| Active | 20px circle, `2px solid --accent` border, pulsing `7px` dot inside | `--text-primary`, "+ running… label in accent mono" |
| Done | 20px circle, `#10b981` bg, white checkmark SVG | `--text-secondary` |

Active row gets `--bg-elevated` background pill.

**Pipeline stages (in order):**
1. Query rewriting (280ms)
2. Classification (360ms)
3. Cache lookup (320ms)
4. Parallel data fetch (920ms) — longest
5. Evidence scoring (310ms)
6. LLM formatting (680ms)
7. Validation & cache (240ms)

On completion → transition to Results screen.

---

### 3. Results Screen (`/query`)
**File:** `src/app/query/page.tsx` + `src/components/results/`

**Layout:** `max-width: 1100px`, two-column flex on desktop:
- Left sidebar: `210px` sticky, `top: 66px`
- Main content: `flex: 1`, `min-width: 0`, gap `0.875rem` between sections

**Search bar** (top, `max-width: 680px`): same style as home but smaller — `10px` vertical padding.

**Meta row:** pill tags for `query_type`, `model_used`, `latency` — monospace, `0.72rem`, colour-tinted for query type.

#### Left Sidebar
Sticky section navigation:
- Label: `0.65rem` uppercase mono `--text-muted`
- Section buttons: `0.78rem`, active = weight 600 + `--bg-elevated` bg
- Colour dot per section: 6px circle, colour = `LOE_CLR[section.loe]`
- Flowchart entries: 6×6px rounded-2 square, `#818CF8`
- Table entries: 6×6px rounded-2 square, `#22D3EE`
- References link at bottom, `--text-muted` dot

#### Hero Card
- Border-radius: `--radius-xl`
- Border: `rgba(59,130,246,0.22)`
- Background: `linear-gradient(135deg, --bg-surface 0%, --bg-elevated 55%, rgba(59,130,246,0.08) 100%)`
- Radial glow overlays (pointer-events: none): top-right blue, bottom-left green
- Eyebrow: `0.65rem` uppercase, `rgba(96,165,250,0.85)`
- Headline: `clamp(1.2rem, 3vw, 1.7rem)`, weight 700, `letter-spacing: -0.025em`
- Direct answer box: `rgba(255,255,255,0.04)` bg, `rgba(255,255,255,0.09)` border, `--radius-md`
- Key point bullets: `5px` blue dot, `0.85rem` body text
- Caveat chips: `rgba(239,68,68,0.08)` bg, `rgba(239,68,68,0.22)` border, `border-radius: 20px`, `rgba(252,165,165,0.9)` text, `⚠` prefix
- Stats pills: `rgba(255,255,255,0.05)` bg, `rgba(255,255,255,0.08)` border, `border-radius: 20px`

#### Evidence Quality Bar
Thin `5px` stacked bar: emerald (LOE I) | blue (LOE II) | slate (LOE III) proportional to claim counts. Label `0.65rem` mono left, counts right.

#### Standard Section Card
- `--bg-surface` bg, `--border` border, `--radius-lg`
- Header (with title + LOE/COR badge row): `13px 15px 11px` padding, `--border` bottom
- Claims: `0 15px` padding, each claim `11px 0` padding, `--border` bottom except last
- Claim layout: `4px` muted dot + text flex row; badges + source right-aligned

#### Renal Table (special render)
- eGFR spectrum bar: 7px height, `linear-gradient(90deg, #ef4444, #f97316, #f59e0b, #10b981)`
- Table grid: `90px 1fr 110px 100px` columns
- Row colours by safety: safe=emerald@6%, caution=amber@6%, limited=orange@6%, contra=red@6%
- Safety label pill: 20px border-radius, matching colour

#### Drug Interactions (special render)
- Grouped by severity: Major (red), Moderate (amber)
- Group header: `7px` colour dot + uppercase label + count
- Interaction rows: coloured bg + dashed border matching severity, `--radius-md`

#### Flowchart Section
- Card with `#818CF8` 8×8 square header dot
- **Normal step**: left column with numbered circle (22px, coloured bg/border) + vertical connector line; right: step box
  - First step: indigo `#818CF8`; last step: cyan `#22D3EE`; middle: `--accent`
- **Branch step** (step text contains `→`): 3-column layout:
  - Condition box (amber `rgba(245,158,11,…)`) left
  - Horizontal arrow (amber line + filled triangle)
  - Outcome box (dashed amber border, amber text, weight 600) right

#### Data Table Section
- Card with `#22D3EE` 8×8 square header dot
- `<table>` with `border-collapse: collapse`
- `thead`: `--bg-elevated` bg, `0.75rem` uppercase `--text-muted` headers, weight 600
- `tbody` rows: `--border` row dividers, hover → `--bg-elevated`
- First column: weight 600 `--text-primary`
- LOE column: coloured badge (see Evidence Badge Colours)
- COR column: coloured badge
- Other columns: `0.84rem --text-secondary`

#### Related Queries
Full-width button rows (not chips):
- Left: search icon in `--accent`
- Middle: `0.85rem` `--accent` text, underline with `rgba(59,130,246,0.35)` colour, `text-underline-offset: 3px`
- Right: chevron `--text-muted`
- Hover: `--bg-elevated` bg
- Clicking triggers a new search immediately

#### Collapsible sections
References, Evidence Glossary, Token Cost: accordion with chevron rotate on open, `200ms ease`.

---

## Interactions & Transitions

| Interaction | Detail |
|---|---|
| Screen change | `fadeUp` animation on new screen mount (opacity + translateY) |
| Search submit | `onSubmit` → set loading screen → pipeline animation → results |
| Theme toggle | `document.documentElement.dataset.theme = 'dark'|'light'`, persisted in `localStorage` |
| Section nav click | Smooth scroll to section anchor (`scrollY - 72px` offset for sticky header) |
| Related query click | Immediately triggers new search (same as form submit) |
| Hover states | 150–200ms ease transitions on bg, border, color, transform |
| Loading pipeline | Sequential `setTimeout` chain per stage; progress bar width = elapsed/total |

---

## Key Component Changes vs Current Codebase

| Area | Current | New design |
|---|---|---|
| Font | system-ui/Inter | DM Sans + DM Mono |
| Background | `#0f172a` | `#07101e` (deeper) |
| Logo | Activity icon from lucide | Favicon SVG (see Assets) |
| Results layout | Stacked full-width cards | Sticky sidebar + main article |
| Renal table | 4 ClaimRow items | Color-coded eGFR table with spectrum bar |
| Interactions | ClaimRow items | Severity-grouped (Major / Moderate) with coloured rows |
| Flowcharts | Mermaid diagram | Custom CSS/HTML vertical step flow with branch side-boxes |
| Tables | Basic HTML table | Styled table with badge columns, hover rows, monospace headers |
| Related topics | Chip pills | Full-width linked rows with chevron |
| Loading screen | Not shown in prototype | 7-stage pipeline animation |

---

## Assets

### Favicon / Logo SVG
Used in the header (30px) and hero icon (52px in a 72px container).

```svg
<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="glowSec" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="8" result="coloredBlur"/>
      <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id="glowPri" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="12" result="coloredBlur"/>
      <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
  <path d="M 150 160 L 70 256 L 150 352" stroke="#818CF8" fill="none" stroke-width="28"
    stroke-linecap="round" stroke-linejoin="round" filter="url(#glowSec)"/>
  <path d="M 362 160 L 442 256 L 362 352" stroke="#818CF8" fill="none" stroke-width="28"
    stroke-linecap="round" stroke-linejoin="round" filter="url(#glowSec)"/>
  <path d="M 70 256 L 180 256 L 215 140 L 275 380 L 310 256 L 442 256" stroke="#22D3EE"
    fill="none" stroke-width="28" stroke-linecap="round" stroke-linejoin="round"
    filter="url(#glowPri)"/>
</svg>
```

Already in the repo at `frontend/src/app/favicon.svg`.

---

## Files in This Bundle

| File | Description |
|---|---|
| `Iatronix Prototype.html` | Full interactive prototype — open in browser to see all screens |
| `README.md` | This document |

## How to Use in Claude Code

1. Open your Iatronix codebase in Claude Code
2. Upload this zip or reference this README
3. Tell Claude Code: *"Implement the UI redesign described in README.md into the existing Next.js/Tailwind codebase. Reference Iatronix Prototype.html for visual fidelity."*
4. Prioritise changes in this order:
   - `globals.css` (tokens + font import)
   - `layout/Header.tsx` (new logo, DM Sans)
   - `app/page.tsx` (home screen)
   - `components/LoadingScreen.tsx` (pipeline animation)
   - `components/results/ResultChrome.tsx` + `AdaptiveResultRenderer.tsx` (results layout)
   - New components: `FlowchartRenderer` (custom CSS, replace Mermaid), `DataTableSection`
